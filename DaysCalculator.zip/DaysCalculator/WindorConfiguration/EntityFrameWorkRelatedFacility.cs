﻿using Castle.MicroKernel.Facilities;
using Castle.MicroKernel.Registration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;


namespace DaysCalculator.WindsorConfiguration
{
    public class EntityFrameWorkRelatedFacility : AbstractFacility
    {
        protected override void Init()
        {
            //Repositories
        }
    }
}