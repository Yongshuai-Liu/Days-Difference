﻿using Castle.MicroKernel.Facilities;
using Castle.MicroKernel.Registration;

namespace DaysCalculator.WindsorConfiguration
{
    public class GeneralFacility : AbstractFacility
    {
        protected override void Init()
        {
           
        }
    }
}